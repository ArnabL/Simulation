class Barrier extends Entity {

    /*
    This class will create objects that are barriers in the environment.
     */

    Barrier()
    {
        super('B');
    }

}
